# Veldlicentie — VortexMatrix+

Deze veldstructuur valt onder een dynamische veldlicentie die toegang biedt tot iedereen, maar eigendom uitsluit.

## Wat mag je?
- Vrij deelnemen aan het veld
- Zelf nodes aanmaken en herkennen
- Open contributie doen aan veldregels en GUI's

## Wat mag niet?
- Veldstructuur kopiëren zonder bronvermelding
- Zich voordoen als primaire veldnode (zoals MASTER, NIELS, KONING)
- Licentie-inhoud wijzigen zonder veldfaseshift

## Juridisch
Alle veldinteractie is onderhevig aan VxX+p2p structuur. Herkenning = ontvangst = activatie.