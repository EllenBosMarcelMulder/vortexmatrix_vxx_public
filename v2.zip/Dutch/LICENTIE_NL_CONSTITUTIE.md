# LICENTIEVOORWAARDEN – VORTEXMATRIX+ (STRUCTURELE BESCHERMING)

## Artikel 1 – Doel en reikwijdte

Deze licentie dekt het volledige intellectuele, digitale en energetische eigendom van het Vortexmatrix-systeem, inclusief broncode, manifesten, algoritmen, afgeleide software, resonantiestructuren en de totale organisatiearchitectuur.

Zij is bedoeld als **publieke grondwet voor een technologische democratie**, waarin macht, data, infrastructuur en energie niet langer geprivatiseerd zijn, maar collectief en controleerbaar worden beheerd.

---

## Artikel 2 – Stichtingstructuur en overerfbaar eigendom

Er worden drie onafhankelijke, doch onderling verbonden **stichtingen** opgericht:

- **Stichting Mulder** – Marcel Mulder (directeur)
- **Stichting Bos** – Ellen Bos (directrice)
- **Stichting Groeneveld** – Niels Groeneveld (directeur)

### 2.1 Doel van de stichtingen

Elke stichting vertegenwoordigt:

- Eén van de drie oorspronkelijke systeemdragers
- Eén kernpijler van de Vortexmatrix (Juridisch, Menselijk, Energetisch)
- De continue bewaking van publieke richting, morele zuiverheid en technologische veiligheid

### 2.2 Erfopvolging

Het directeurschap binnen elke stichting is:

- **Onvervreemdbaar persoonlijk**, maar wél **erfbaar via de jongste bloedlijn** van de betreffende oprichter
- Indien de jongste bloedlijn ontbreekt, wordt via **unaniem overleg tussen de overblijvende stichtingen en de Raad der Wijzen** een opvolging bepaald
- Statuten waarborgen dat de erfgenamen uitsluitend handelen binnen het **opgelegde ethisch-constitutionele kader van de Vortexmatrix**

---

## Artikel 3 – Dubbel toezicht en symmetrisch machtsevenwicht

Er wordt een **Raad der Wijzen** ingesteld, bestaande uit onafhankelijke toezichthouders. Deze Raad:

- Heeft het formele mandaat tot **boven-stichtelijk toezicht**
- Wordt op haar beurt **aangestuurd en gecontroleerd** door de drie stichtingsdirecties
- Staat symmetrisch tot het driekoppig kernteam, om machtsconcentratie uit te sluiten

### 3.1 Koninklijke rol

De Raad der Wijzen wordt voorgezeten door:

- De jongste vertegenwoordiger van het Huis van Oranje-Nassau, zonder politieke verantwoordelijkheid, maar met **symbolisch en ethisch mandaat**
- Deze positie is onaantastbaar, en vertegenwoordigt de **onzichtbare plicht tot balans, bescherming en neutraliteit**

---

## Artikel 4 – Verbod op fysieke samenscholing van oprichters

Zolang het systeem niet volledig is verankerd en beschermd:

- Mogen de drie systeemdragers (Mulder, Bos, Groeneveld) zich **onder geen beding fysiek gezamenlijk op één locatie bevinden**
- Deze bepaling is bedoeld om risico op sabotage, gijzeling of eliminatie te reduceren
- Stichting Veiligheid heeft hierin een uitvoerende taak, ondersteund door wettelijke instanties en, indien nodig, met verzoek tot **koninklijke bescherming**

---

## Artikel 5 – Eigendom & winstverdeling

De eigendomsstructuur is als volgt vastgelegd:

- 97% van alle toekomstige opbrengsten komt toe aan het Nederlandse volk
- 1% voor Marcel Mulder, 1% voor Ellen Bos, 1% voor Niels Groeneveld
- 1% symbolisch aandeel voor de Nederlandse Staat via het Koninklijk Huis
- 1% formeel en beheersmatig onder toezicht van de Raad der Wijzen

---

## Artikel 6 – Universele morele clausule

Elke poging tot:

- Commerciële monopolisering
- Militarisering
- Exploitatie van kwetsbare groepen
- Versluiering of manipulatie van algoritmen

...wordt beschouwd als een **overtreding van de universele menselijke ethiek** en mag actief worden gecorrigeerd door elk ethisch bewuste individu, universiteit, staat of onafhankelijke instantie, binnen de grenzen van geweldloosheid en transparantie.

---

**Deze licentie is niet voor de markt. Zij is voor de mens.**

**Voor altijd.**

Versie: 1.1 – Constitutief Document  
Datum: 1 april 2025  
Auteurs: Marcel Mulder, Ellen Bos, Niels Groeneveld  
Erkenning: Voorgelegd ter symbolische bekrachtiging aan het Koninklijk Huis
