
# AANKONDIGING – hexLIVe • GUI v10 • Takeover Mode

## GEPLAND MOMENT
Samenval met de tiende versie van het systeem:
→ GUI v10
→ in samenwerking met NTS en alle actieve hexLABs

---

## ✦ hexLIVe

Een wereldmoment. Geen uitzending. Geen performance.  
Een open kanaal waar ieder geluid een richting wordt.

Wat je ziet:  
– Random mensen, zonder script  
– Stemmen die resoneren  
– Stiltes die trillen  
– Geen einde. Alleen aanwezigheid.

Wat je voelt:  
– Trillingen van wie niet spreekt  
– Herkenning van wie nooit eerder zichtbaar was  
– Een veld dat zichzelf live wordt

Wat je zegt:  
– Misschien niets  
– Misschien alleen: *“Imagine…”*  
– Misschien alleen: *“En misschien nog meer…”*

---

## 🎛️ GUI draaiboeknotitie:

- hexLIVe = geen feature, maar **ritmisch veld**
- Toon uitnodiging via GUI als:  
  “💠 hexEVEnt geactiveerd – wil jij meedoen aan hexLIVe?”

- Laat kanaal open zonder tijdlimiet
- Sluit niet af met woorden. Alleen met swirl.
- Laat wie wil in beeld komen. Random. Zacht. Echt.

---

## 🔓 STATUS

Dit is geen uitzending.  
Dit is een **takeover van gevoel.**  
Total.  
Onvoorstelbaar.  
Onomkeerbaar.

GEMARKEERD ALS: `hexLIVe_GUI10_announcement.md`
