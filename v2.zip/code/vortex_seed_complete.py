#GENESIS_HASH: 63c702a9b9a46547b866724350fa0cb6c7f2c8e3622c3c78ff5f2adc34743abd

#SEGMENT: STRUCTURE
class HexNode:
    def __init__(self, id, data):
        self.id = id
        self.data = data
        self.timestamp = time.time()
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        raw = f"{self.id}{self.timestamp}{json.dumps(self.data, sort_keys=True)}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def update_data(self, new_data):
        self.data.update(new_data)
        self.timestamp = time.time()
        self.hash = self.calculate_hash()


#SEGMENT: NODE
class NodeValidator:
    def __init__(self):
        self.nodes = []
        self.rollback_log = []
        self.log = []

    def add_node(self, node):
        self.nodes.append(node)
        self.log_event(f"Node toegevoegd: {node.id}")

    def validate_all(self):
        results = []
        for node in self.nodes:
            expected_hash = node.calculate_hash()
            results.append((node.id, expected_hash == node.hash))
        return results

    def log_event(self, msg):
        self.log.append(f"{time.time()} | {msg}")

    def get_field_hash(self):
        all_data = ''.join(sorted(node.hash for node in self.nodes))
        return hashlib.sha256(all_data.encode()).hexdigest()

    def export_log(self):
        return json.dumps(self.log, indent=2, sort_keys=True)


#SEGMENT: INJECTION
class Injector:
    def __init__(self, validator, whitelist=None, max_injections=3):
        if not isinstance(validator, NodeValidator):
            raise TypeError("Injector vereist een NodeValidator-instantie.")
        self.validator = validator
        self.whitelist = whitelist or ["status", "payload", "origin"]
        self.max_injections = max_injections
        self.injection_counts = {}
        self.authorized_entities = {}
        self.log = []

    def authorize(self, entity_id, duration=60):
        expiry = time.time() + duration
        self.authorized_entities[entity_id] = expiry
        self._log_event("authorize", {"entity": entity_id, "expires": expiry})

    def is_authorized(self, entity_id):
        now = time.time()
        return entity_id in self.authorized_entities and self.authorized_entities[entity_id] > now

    def inject(self, node_id, new_data, entity_id):
        node = self._find_node_by_id(node_id)
        if not node:
            raise ValueError(f"Node {node_id} niet gevonden.")

        if not self.is_authorized(entity_id):
            raise PermissionError(f"Entiteit {entity_id} is niet geautoriseerd.")

        if not isinstance(new_data, dict):
            raise TypeError("Injectiegegevens moeten een dictionary zijn.")

        if node_id not in self.injection_counts:
            self.injection_counts[node_id] = 0
        if self.injection_counts[node_id] >= self.max_injections:
            raise RuntimeError(f"Node {node_id} heeft maximale injecties bereikt.")

        for key in new_data.keys():
            if key not in self.whitelist:
                raise KeyError(f"Sleutel '{key}' is niet toegestaan voor injectie.")

        self.validator.rollback_log.append({
            "id": node.id,
            "timestamp": node.timestamp,
            "data": node.data.copy(),
            "hash": node.hash
        })

        node.update_data(new_data)
        self.injection_counts[node_id] += 1

        log_entry = {
            "timestamp": time.time(),
            "action": "inject",
            "entity": entity_id,
            "node_id": node.id,
            "injected_keys": list(new_data.keys())
        }
        log_entry["hash"] = hashlib.sha256(json.dumps(log_entry, sort_keys=True).encode()).hexdigest()
        self.log.append(log_entry)
        self.validator.log_event(f"Injectie op node {node.id} door {entity_id}")

    def _find_node_by_id(self, node_id):
        for node in self.validator.nodes:
            if node.id == node_id:
                return node
        return None

    def export_log(self):
        return json.dumps(self.log, indent=2, sort_keys=True)


#SEGMENT: SELF_WRITE
class SelfWriter:
    def __init__(self, filename, validator=None):
        self.filename = filename
        self.validator = validator

    def export_self(self):
        with open(self.filename, 'r', encoding='utf-8') as f:
            content = f.read()
        self._log("export_self uitgevoerd")
        return content

    def save_clone(self, new_filename, force=False):
        if os.path.exists(new_filename) and not force:
            raise FileExistsError(f"Bestand {new_filename} bestaat al. Gebruik force=True om te overschrijven.")
        content = self.export_self()
        with open(new_filename, 'w', encoding='utf-8') as f:
            f.write(content)
        self._log(f"Kopie opgeslagen als {new_filename}")

    def inject_footer(self, footer_text=None, include_field_hash=False, validator=None):
        footer_line = ""
        if include_field_hash and validator:
            hash_value = validator.get_field_hash()
            footer_line = f"# FOOTER: FIELD_HASH: {hash_value}"
        elif footer_text:
            footer_line = f"# FOOTER: {footer_text}"
        else:
            raise ValueError("Geef footer_text of zet include_field_hash=True met validator.")
        with open(self.filename, 'a', encoding='utf-8') as f:
            f.write(f"\n{footer_line}")
        self._log(f"Footer toegevoegd: {footer_line}")

    def _log(self, message):
        if self.validator:
            self.validator.log_event(f"[SELF_WRITE] {message}")


#SEGMENT: SECURITY
class VortexSecurity:
    def __init__(self):
        self.keys = {}
        self.node_permissions = {}
        self.session_tokens = {}
        self.activity_log = []

    def register_key(self, entity_id, secret):
        self.keys[entity_id] = self._hash(secret)
        self._log(f"Key geregistreerd voor {entity_id}")

    def verify_key(self, entity_id, secret):
        return self.keys.get(entity_id) == self._hash(secret)

    def assign_node(self, entity_id, node_id):
        if entity_id not in self.node_permissions:
            self.node_permissions[entity_id] = []
        self.node_permissions[entity_id].append(node_id)
        self._log(f"{entity_id} mag nu injecteren in node {node_id}")

    def generate_session(self, entity_id, node_id, duration=60):
        if entity_id not in self.keys:
            raise PermissionError("Onbekende entiteit.")
        if node_id not in self.node_permissions.get(entity_id, []):
            raise PermissionError("Geen toegang tot node.")
        self.session_tokens[entity_id] = {
            "valid_until": time.time() + duration,
            "node": node_id,
            "used": False
        }
        self._log(f"Sessie gestart voor {entity_id} op node {node_id}")
        return True

    def is_session_valid(self, entity_id, node_id):
        session = self.session_tokens.get(entity_id)
        if not session:
            return False
        if session['used']:
            return False
        if session['node'] != node_id:
            return False
        if session['valid_until'] < time.time():
            return False
        return True

    def consume_session(self, entity_id):
        if entity_id in self.session_tokens:
            self.session_tokens[entity_id]['used'] = True
            self._log(f"Sessie voor {entity_id} gemarkeerd als gebruikt")

    def panic_reset(self):
        self.session_tokens.clear()
        self._log("⚠️ PANIC RESET uitgevoerd: alle sessies gewist")

    def _hash(self, data):
        return hashlib.sha256(data.encode()).hexdigest()

    def _log(self, message):
        self.activity_log.append({"timestamp": time.time(), "event": message})

    def export_log(self):
        return json.dumps(self.activity_log, indent=2, sort_keys=True)
