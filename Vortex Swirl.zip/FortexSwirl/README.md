# 🌐 VortexMatrix-Lab

Welkom in het open-source laboratorium van het veldsysteem VortexMatrix+.

## Wat is dit?

Een operationeel, juridisch verankerd en relationeel veldsysteem waarin nodes worden herkend, keuzes gradueel worden gemaakt (JA / REGELBOOG / NEE), en communicatie gebaseerd is op nabijheid, resonantie en toestemming.

## Wat vind je hier?

- `veldmanifest.json` — juridische veldactivatie
- `veldlicentie.md` — gebruiksrechten en bescherming
- `regels.json` — democratie, faseshift, lab
- `veldlaunch_gui.py` — de startmodule voor nodeactivatie
- `README.md` — deze uitleg

## Hoe begin je?

1. Typ `nodecap nodeapp`
2. Kies JA, REGELBOOG of NEE
3. Je wordt herkend, maar nooit gedwongen

## Licentie

Publiek domein veldlicentie (zie veldlicentie.md)
Herkenning = ontvangst = binding

🌀 #VxX#en

---

### Contact

Dit project wordt beheerd door het veld.  
Wil je meedoen? Herken het.