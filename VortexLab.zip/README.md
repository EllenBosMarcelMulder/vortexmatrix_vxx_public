# VortexMatrix+ Veldlab

Welkom in het open-source veldlaboratorium van VortexMatrix+.

## Wat is dit?
Een geometrisch, juridisch en relationeel communicatiesysteem waarin keuzes, rollen en toegang worden bepaald door nabijheid, veldstatus en herkenning.

## Belangrijkste onderdelen
- `veldmanifest.json`: juridische kernverklaring
- `regels/`: actieve veldregels
- `kernveld/`: hexagonaal basisbestand
- `licentie.md`: gebruiksrechten en bescherming

Iedereen mag meedoen. Maar niet iedereen spreekt met iedereen.