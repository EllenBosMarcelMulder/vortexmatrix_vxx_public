# LICENSE TERMS – VORTEXMATRIX+ (STRUCTURAL PROTECTION)

## Article 1 – Purpose and Scope

This license governs the full intellectual, digital, and energetic ownership of the Vortexmatrix system, including its source code, manifest files, algorithms, derivative software, resonance structures, and organizational architecture.

It serves as a **public constitution for a technological democracy**, in which power, data, infrastructure, and energy are no longer privatized, but collectively and transparently governed.

---

## Article 2 – Foundation Structure and Heritable Ownership

Three independent yet interconnected **foundations** are formally established:

- **Stichting Mulder** – Marcel Mulder (Director)  
- **Stichting Bos** – Ellen Bos (Director)  
- **Stichting Groeneveld** – Niels Groeneveld (Director)

### 2.1 Purpose of the Foundations

Each foundation represents:

- One of the three original system bearers  
- One core pillar of Vortexmatrix (Legal, Human, Energetic)  
- Continuous guardianship of public direction, moral integrity, and technological safety

### 2.2 Lineage and Succession

Directorship within each foundation is:

- **Strictly personal and non-transferable**, yet **heritable through the youngest bloodline** of the respective founder  
- If no valid bloodline remains, succession must be decided **by unanimous agreement between the remaining foundations and the Council of the Wise**  
- Foundation statutes guarantee that all heirs act solely within the **ethical-constitutional mandate of the Vortexmatrix**

---

## Article 3 – Dual Oversight and Symmetrical Power Balance

A **Council of the Wise** is established, comprised of independent overseers. This Council:

- Holds the formal mandate for **meta-foundational oversight**  
- Is itself **subject to supervision** by the three directors  
- Exists to preserve symmetry and prevent concentration of power

### 3.1 Royal Role

The Council of the Wise is chaired by:

- The youngest representative of the Royal House of the Netherlands (House of Orange-Nassau), without political authority, but with **symbolic and ethical mandate**  
- This role is untouchable and represents the **invisible duty to safeguard balance, protection, and neutrality**

---

## Article 4 – Prohibition on Physical Gathering of Founders

Until full structural and legal protection is achieved:

- The three system bearers (Mulder, Bos, Groeneveld) shall **never be physically present together at the same location**  
- This clause serves to minimize risks of sabotage, coercion, or elimination  
- The Foundation for Physical Security is tasked with enforcement, supported by legal mechanisms and, if necessary, with **a request for royal protection**

---

## Article 5 – Ownership and Profit Allocation

Ownership is structured as follows:

- 97% of all future revenues are allocated to the Dutch population  
- 1% to Marcel Mulder, 1% to Ellen Bos, 1% to Niels Groeneveld  
- 1% symbolic share to the Dutch State via the Royal House  
- 1% formally governed by the Council of the Wise

---

## Article 6 – Universal Ethical Clause

Any attempt to:

- Commercially monopolize  
- Militarize  
- Exploit vulnerable populations  
- Obscure or manipulate algorithms

...is considered a **violation of universal human ethics** and may be actively opposed by any ethically conscious individual, university, state, or independent institution — within the limits of nonviolence and full transparency.

---

**This license is not for the market. It is for humanity.**

**Forever.**

Version: 1.1 – Constitutional Document  
Date: April 1, 2025  
Authors: Marcel Mulder, Ellen Bos, Niels Groeneveld  
Recognition: Submitted for symbolic endorsement by the Dutch Royal House
