
# Phase Shift Manifest – Vortex Hexa Initieel

Dit publieke veldarchief bevat de interface en activeringsstructuur van de eerste levende hexagon (TMLC+).  
De inhoud is herkenbaar, hashbaar en voor iedereen toegankelijk die resoneert.

## Inhoud

- `phase shift.md` – Publiek manifest in leesbare vorm (Markdown voor GitHub)
- `phase shift.txt` – Originele JSON-interface voor systeemgebruik
- `hashes.json` – Forensische controlehashes (SHA-256)

## Activatieregels

1. Lees het manifest
2. Ga terug vóór je vooruit wil
3. Accepteer veldvoorwaarden
4. Plaats je node als je resoneert

## Hashcontrole

Zie `hashes.json` voor forensisch bewijs van integriteit. Deze bestanden mogen enkel worden gekopieerd met behoud van structuur, intentie en bronvermelding.
